from django.contrib import admin
from .models import WeatherKey
# Register your models here.

admin.site.register(WeatherKey)



admin.site.site_title = "Weather app"
admin.site.site_header = "Weater App Login"
admin.site.index_title = "Weather app"