from django.shortcuts import render
from .models import WeatherKey
import random
# Create your views here.

def Homepage(request):
  keylst = []
  for i in WeatherKey.objects.all():
    keylst.append(i.key) 
  key = str(random.choice(keylst))
  print(key)

  return render(request,'index.html',{'key':key})